for var in *
do
	if [ $var == "D1" -o $var == "Demo" -o $var == "demo-1" -o $var == "test.log" ]
then
	continue
else
	echo "$var"
fi
done
