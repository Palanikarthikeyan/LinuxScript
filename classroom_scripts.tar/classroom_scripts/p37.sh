
for v in p1.log p2.log p3.log p4.log p5.log
do
	if [ $v  == "p2.log" ];then
		continue
	else
		echo "$v"
        fi
done
