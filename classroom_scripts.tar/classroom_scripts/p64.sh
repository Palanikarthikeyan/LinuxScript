if [ $# -ne 1 ];then
	echo "Usage: commandline args required single input file"
	echo "$0 <filename"
	exit
fi
if ! [ -f $1 ];then
	echo "Usage: Sorry file:$1 is not a reg.file"
	exit
fi
	
while read var
do
	echo "-->$var"
done<$1
