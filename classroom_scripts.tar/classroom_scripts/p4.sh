# variable=value
#
# variable=`command` (or) variable=$(command) 
# 
d=`date +%D`
os=`uname`
c=`ps -e|wc -l`
echo "Today:$d
--------------------
working kernel:$os
---------------------
Total no.of process count:$c
---------------------------------"
