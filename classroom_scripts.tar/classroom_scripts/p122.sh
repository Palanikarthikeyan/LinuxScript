
if [ $# -eq 0 ];then
	echo "Usage: commandline args is empty"
	echo "$0 <package> <package> ..<Package>"
	exit
fi
    
f1(){
    # f1 block - checking package is intalled or not 
    for var in $@
    do
	rpm -q $var >/dev/null 2>&1
	if [ $? -eq 0 ];then
		echo "package:$var is installed"
		f3 $var # nested call with argument
	else
		echo "package:$var is not installed"
		f2 $var # nested function call with argument
		
	fi
    done
}

f2(){
     # f2 block - installing package
    if [ `whoami` == "root" ];then
	v="`date +%H-%M_mts_%m-%s`"
	rpm -ivh $1 >>/var/log/mypackage_$v.log
	if [ $? -eq 0 ];then
		echo "Success"
		f3 $1
	else
		echo "package $1 installation is failed - refer /var/log/mypackage_$v.log file"
	fi
    else
	echo "Sorry `whoami` your not root user"
	exit
    fi
}

   f3(){
	echo "about $1 package information:-"
	echo 
	rpm -qi $1
   	echo 
   }

f1 $@
