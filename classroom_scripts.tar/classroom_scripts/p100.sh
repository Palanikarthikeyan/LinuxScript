Total=(`free -m|awk '{print $2}'|sed -e '1d' -e '3d'`)

t=0
for v in ${Total[@]}
do
	t=`expr $v + $t`
done
echo "Total memory used:$t"

Used=(`free -m|awk '{print $3}'|sed '1d'`)
t=0
for v in ${Used[@]}
do
	t=`expr $v + $t`
done
echo "Total Used:$t"

Free=(`free -m|awk '{print $4}'|sed '1d'`)
t=0
for v in ${Free[@]}
do
	t=`expr $v + $t`
done
echo "Total Free space:$t"
