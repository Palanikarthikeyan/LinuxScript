#source "./p91"
. "/home/apelix/LinuxScript/p91"
echo $var
f1
f2
echo "Exit from code block"
