echo "
**************** System Info ************************

  1. Kernel and version
  2. Shell name and version
  3. Display mounted file system
  4. Today date 
*****************************************************"
read -p "Enter your choice:" choice

case $choice in
1)  echo "Kernel name:$(uname) Version:$(uname -r)" ;;
2)  echo "Login shell name:$SHELL  Version:$BASH_VERSION" ;;
3)  echo "Mounted File system details:-"
    df -Th
    ;;
4)  echo "Today:$(date +%D)"  ;;
*)  echo "Sorry $choice is invalid choice"
esac
