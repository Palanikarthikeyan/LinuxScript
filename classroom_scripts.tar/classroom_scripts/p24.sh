read -p "Enter a file name:" fname
if [ -e $fname ];then
	if [ -f $fname ];then
		echo "file:$fname is a reg.file"
		ls -l $fname
	elif [ -d $fname ];then
		echo "file:$fname is a directory"
		ls -ld $fname
	else
		echo "file $fname is belongs to `file $fname`"
	fi
else
	echo "Sorry file:$fname is not exists"
fi
