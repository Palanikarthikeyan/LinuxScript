calc(){
	t=0
	for v in $@
	do
		t=`expr $v + $t`
	done
	echo "total:$t"
}
