echo "This is shell script"
echo "this is shell script"
module="sys"
v=`python<<abc
import $module
print $module.version
abc`
echo
echo "my working system python version:$v"
echo "exit from script"
