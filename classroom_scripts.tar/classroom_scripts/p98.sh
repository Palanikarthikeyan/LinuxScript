counters=("100G" "200G" 350G 500G)
total=0
for var in ${counters[@]}
do
	r=`echo $var|sed 's/.$//'`
	total=`expr $total + $r`
done
echo "Sum of counters:$total"
	
