read -p "Enter a codeNumber:" code

case $code in
data)  echo "Matched-1" ;;
101)   echo "Matched-2" ;;
1.45)  echo "Matched-3" ;;
F)     echo "MAtched-4" ;;
%)     echo "Matched-5" ;;
*)     echo "Not-matched" ;;
esac
