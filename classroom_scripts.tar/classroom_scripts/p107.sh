# awk -F, '$2 == "sales" {print NR,$1,$NF}' emp.csv
#
awk 'BEGIN{
FS=","
}
{
if($2 == "sales"){
	print NR,$1,$NF
}
}' emp.csv
