

f2(){
	yum -y install $1 >/var/log/pk.log 2>&1
	if [ $? -ne 0 ];then
		echo "Package installation failed"
		echo "read /var/log/pk.log file"
		exit
	fi

}
f2 httpd # function call with argument

arr=(irb ksh zsh)
for var in ${arr[@]}
do
	f2 $var # function call with argument
done


