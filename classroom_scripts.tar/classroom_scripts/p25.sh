os=`uname`

if [ $os == "winx" ];then
	echo "Matched1"
elif [ $os == "unix" ];then
	echo "Matched2"
elif [ $os == "sunos" ];then
	echo "Matched3"
elif [ $os == "aix" ];then
	echo "Matched4"
elif [ $os == "Linux" ];then
	echo "Matched5"
else
	echo "Not-Matched"
fi
echo 
case $os in
winx)  echo "Matched1" ;;
unix)  echo "Matched2" ;;
sunos) echo "Matched3" ;;
aix)   echo "Matched4" ;;
Linux) echo "Matched5" ;;
*)     echo "Not-Matched" ;;
esac
