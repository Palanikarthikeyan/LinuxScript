read -p "Enter a server name:" sname
if [ $sname == "unix" ];then
	read -p "Enter a shell name:" svar
	case $svar in
	sh)  profile=".profile"
	     port=1234
	     History=".history"
		;;
	ksh) profile=".kshrc"
	     port=4502
	     History=".ksh_history"
		;;
	bash) profile=".bashrc"
	      port=4234
	      History=".bash_history"
		;;
	*) echo "shell $svar is not matched"
           profile="/etc/profile"
	   port=000
           History="/tmp/history"
	esac
elif [ $sname == "winx" ];then
	read -p "Enter a shell name:" svar
	case $svar in
	psh)  profile="C:\\profile"
	      port=9449;History="C:\\cmdhistroy"
		;;
	tcsh) profile="~/.tcsh";port=49234;History="~/.tcshHistory" ;;
	 *)   echo "shell :$svar is not matched"
	      profile="C:\\winprofile" ; port=000; History="D:\\history"
	esac
else
	echo "Sorry input server name:$sname is not matched"
fi

echo -e "Server:$sname\nShell:$svar\nProfile:$profile\nport:$port\nHistory:$History"
