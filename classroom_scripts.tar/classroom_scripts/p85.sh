
fx(){
	var=100 # global variable - by default this variable is global
	echo $var
}
fx
echo "outside:$var" # 100 
					
