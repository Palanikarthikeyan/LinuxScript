for v in $@
do
	echo $v
done
echo "Total no.of args:$#"
