c=0
for v in *
do
	c=`expr $c + 1`
	echo "$c: $v"
done
echo "Total no.of files:$c"
