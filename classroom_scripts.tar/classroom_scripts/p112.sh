BEGIN{
s="root:x:bin:bash"
print s # string 

split(s,A,":")

for(v in A)
	print A[v]
}
