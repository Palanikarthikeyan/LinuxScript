echo "Enter a filename:"
read fname
echo "Enter a IP-Address:"
read IP
echo "Enter a port number:"
read port
echo "input details:-
-----------------------
Filename :$fname
IP:$IP
Port number:$port
-------------------------"
