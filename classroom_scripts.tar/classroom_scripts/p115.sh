

while read -p "Enter some text:" var
do
	if [[ $var =~ ^[A-Za-z].*sales.*[0-9]$ ]];then
		echo "matched"
		echo $var
	fi
done
