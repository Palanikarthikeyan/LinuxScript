# array - collection of data - common name - all the values are different types
# -----
# awk array index is user defined
# ---------
# arrayName[index]=value
BEGIN{
	os[34]="unix"
	os[36]="Linux"
	os[0]=100.45
	os[45]="/etc/passwd"
	os["abc"]=34343.32
	#for(index in array){ -> in keyword
	#	print array[index]
	#}	
	for(x in os){
		print os[x]
	}
}
