
f1(){
	if [ `whoami` == "root" ];then
		f2 # nested call
	else
		echo "Sorry your not root user"
		exit
	fi
	echo "Exit from $FUNCNAME block"
}
f2(){
	yum install httpd >/var/log/repo.log 2>&1
	if [ $? -ne 0 ];then
		echo "package httpd is failed"
		exit 
	fi
	systemctl start  httpd 
	if [ $? -ne 0 ];then
		echo "http service is failed"
		exit
	fi
	echo "Exit from $FUNCNAME block"
}
f1
