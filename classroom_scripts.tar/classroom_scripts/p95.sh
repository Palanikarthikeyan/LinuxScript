getdata(){
	read -p "Enter a filename:" -a fnames
	for var in ${fnames[@]}
	do
		file $var
	done
	echo "Exit from $FUNCNAME block"
}
