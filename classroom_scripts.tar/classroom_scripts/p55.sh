
if [ $# -ne 2 ];then
	echo "Usage: Commandlineargs error"
	echo "$0 <arg1> <arg2>"
	exit
fi
expr $1 + $2

