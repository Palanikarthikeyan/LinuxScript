files=(`find /etc -name "*.sh"`)

for var in ${files[@]}
do
	cat $var|less
done
