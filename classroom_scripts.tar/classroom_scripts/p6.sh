echo "Login Path:$HOME"
echo "Login shell name:$SHELL"

mysh=$SHELL # we can initialize existing shell variable to user defined variable 
echo "myshell variable:$mysh"
