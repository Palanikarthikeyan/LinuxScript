read -p "Enter a filename:" fname
read -p "Enter a field sep:" fsep
read -p "Enter a count value:" fvalue

A=(`cat $fname|cut -d"$fsep" -f $fvalue|sort`)

for var in ${A[@]}
do
	echo "$var"
done
echo "Total no.of elements:${#A[@]}"
