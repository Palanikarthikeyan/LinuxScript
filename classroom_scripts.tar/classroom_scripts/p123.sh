ram,sales,pune,1000	ram,sales,pune,1000	  PID TTY          TIME CMD
yahoo,prod,pune,32450	ashi,prod,bglore,2345	 3635 pts/3    00:00:01 bash
nithin,prod,pune,1236	xerox,sales,chennai,45900	 7924 pts/3    00:00:00 ps
	yahoo,prod,pune,32450	
	anu,HR,hyd,4560	
	biju,prod,bglore,4567	  PID TTY          TIME CMD
	vijay,hr,chennai,3453	
	theeb,sales,hyd,5678	 3635 pts/3    00:00:01 bash
	nithin,prod,pune,1236	 7924 pts/3    00:00:00 ps
