echo "This is shellscript"
echo "This is shellscript"
echo "This is shellscript"
echo
awk 'BEGIN{
print "List of sales emp details:-"
print "---------------------------"
FS=","
}
/sales/{
print
}
END{
print "Thank you"
}' emp.csv 
echo
echo "This is shellscript"
echo "This is shellscript"
