BEGIN{
for(i=0;i<5;i++){
	system("uptime;sleep 2") # system("command")
}
print ""
i=0
while(i<3){
	print "Test block:",i
	i++
}
}
