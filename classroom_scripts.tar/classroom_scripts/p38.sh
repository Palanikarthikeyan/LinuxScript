echo "List of files under $HOME directory"

for var in `ls ~`
do
	echo "$var"
done
echo 
cd ~
for var in `ls`
do
	echo "$var"
done
