select v in menu1 menu2 menu3 menu4
do
	echo "selected menu item:$v"
	break # exit from loop
done
