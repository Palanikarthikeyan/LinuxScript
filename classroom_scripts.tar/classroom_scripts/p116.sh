
read -p "Enter a emp name in title case format:" ename

if [[ $ename =~ ^[A-Z][a-z]+$ ]];then
	echo "Hello...$ename"
else
	echo "Sorry invalid format"
fi
