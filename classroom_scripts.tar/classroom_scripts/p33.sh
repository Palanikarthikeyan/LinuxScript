while :
do
	read -p "Enter a login name:" name
	if [ $name == "root" ]
	then
		echo "Success login is valid" 
		break # exit from loop
	fi
done

if [ $name != "root" ]
then
	echo "Sorry your login is blocked"
fi
