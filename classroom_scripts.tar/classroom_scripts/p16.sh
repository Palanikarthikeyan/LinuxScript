read -p "Enter a portnumber:" port

if [ $port -gt 500 ]
then
	app="Test-1"
else
	app="Test-2"
fi
echo -e "App name:$app\t Port Number:$port"
