i=0
while [ $i -lt 3 ]
do
	read -p "Enter a login name:" name
	i=`expr $i + 1`
	if [ $name == "root" ]
	then
		echo "Success login is valid ...$i attempt"
		break # exit from loop
	fi
done

if [ $name != "root" ]
then
	echo "Sorry your login is blocked"
fi
