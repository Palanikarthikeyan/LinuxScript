#ename="Mr.Raj paul"
#empID=1234
#edept=DBA
#epay=123456.78

echo -n "Enter a emp name:"
read ename
read -p "Enter $ename emp id:" empID
read -p "Enter $ename working dept:" edept
read -p "Enter $ename basic Pay:" epay

echo "About $ename details
--------------------------
Emp Name:$ename
Emp ID:$empID
working dept is:$edept
Basic Pay:$epay
---------------------------"
