f1(){
	ps
	
}
f2(){
	uptime	
	echo
	free -m
}
var=1234
