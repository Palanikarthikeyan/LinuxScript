c=0
for v in p*
do
	c=`expr $c + 1`
	echo "$c: $v"
	mv $v $v.sh
	if [ $? -ne 0 ];then
		echo "Usage: rename operation is failed"
	fi
done
echo "Total no.of files:$c"
