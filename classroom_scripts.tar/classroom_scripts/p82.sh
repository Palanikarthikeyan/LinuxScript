f1(){
	if [ `whoami` == "root" ];then
	   arr=(irb ksh zsh)
	   f2 ${arr[@]} # nested call with arguments
	else
	   echo "Sorry your not root user"
	fi
}

f2(){
	for v in $@
	do
	 yum -y install $v >/var/log/pk.log 2>&1
	 if [ $? -ne 0 ];then
		echo "Package $v installation failed"
		echo "read /var/log/pk.log file"
		exit
	 fi
	done
}
f1
