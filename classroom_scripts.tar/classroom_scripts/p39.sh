echo "List of files under $HOME directory"

cd ~
for var in *
do
	echo "$var"
done

echo "Filter .py files:-"
echo "-------------------------"
for var in *.py
do
	echo "$var"
done
