echo $1 $2 $3 $4
echo $@
echo $*
echo "Total no.of args:$#"
echo ${1} ${5}
echo "10th args:${10}"
