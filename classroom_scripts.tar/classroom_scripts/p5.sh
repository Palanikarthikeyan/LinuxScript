echo "Display current working directory:`pwd`"
dname="demo-1"
fname="test.log"

mkdir $dname
touch $fname
cp $fname $dname
cd $dname
sleep 3
echo # empty line
echo "Display current working directory:`pwd`"


