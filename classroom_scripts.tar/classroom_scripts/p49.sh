test -f p1 && echo "Yes input file is reg.file"

if [ -f p1 ]
then
	echo "Yes input file is reg.file"
fi
