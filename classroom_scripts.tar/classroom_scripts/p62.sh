
A=(101 102 103 104 105 106 107 108 109 110)
 #  0   1    2  3   4   5   6   7   8   9 <== index
 # 
 #
 # ${array[@]:OFFSET:LENGTH}
 #             |       |__ count - 1 2  ...
 #           starts from 0 
echo ${A[@]}
echo ${A[@]:3}
echo ${A[@]:3:4}
echo ${A[@]:0:4}
for v in ${A[@]:0:4}
do
	echo "->$v"
done
