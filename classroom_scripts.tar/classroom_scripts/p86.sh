
fy(){
	local port=5000
	echo "flask application - port number:$port"
}
fy
echo "flask app: port number:$port" 
