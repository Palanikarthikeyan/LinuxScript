echo "Test-1"
#echo "Test-2"
uptime # display cpu loadbalance
# single line comment
# -----------------------
# ----------------------
echo "display login path:"
echo $HOME # $HOME is a shell variable
echo "End of the line"
# end ofthe script
