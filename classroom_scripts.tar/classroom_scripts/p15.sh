read -p "Enter a portnumber:" port

if [ $port -gt 500 ]
then
	echo "Valid port number:$port"
else
	echo "Invalid portnumber:$port"
fi
