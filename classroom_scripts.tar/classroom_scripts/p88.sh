fx(){
	local port=5000
	return $port
}
fx
echo "App port number:$port"
