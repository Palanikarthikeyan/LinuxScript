echo "one"
echo "two"
echo "three"
if [ 10 -eq 10 ]
then
	echo "Yes"
else
	echo "no"
fi
echo "four"
echo "end of the line"
