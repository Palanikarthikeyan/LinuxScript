echo "This is script section"
function Sysinfo(){
	echo "My working kernel name and version:`uname -rs`"
	echo "Login name:`whoami`"
	echo "Login ID:$UID" # id -u
	echo "Exit from $FUNCNAME block"
}
fx(){
	echo "This is fx block"
	echo "today:`date +%D`"
	echo "Exit from $FUNCNAME block"
}
fy(){
	echo "CPU-LoadBalance:-"
	uptime
	echo "Exit from $FUNCNAME block"
}
Sysinfo # 1st call
sleep 2
fy # 2nd call
sleep 1
fx # 3rd call
sleep 2
fy # calling fy block
echo "end of the script"
