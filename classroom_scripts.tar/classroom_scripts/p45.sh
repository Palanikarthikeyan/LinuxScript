select v in unix linux aix sunos winx
do
	echo "selected os name is:$v"
	df -Th
	ps -f
	break
done
