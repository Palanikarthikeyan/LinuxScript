# mysql -u root -p'' use DEMO;
# mysql -u root -p'' show tables;
# mysql -u root -p'' select *from demo_table ;
var=`mysql -u root -p''<<ABC
 use $1; # DEMO
 show tables;
 select *from demo_table;
ABC`

if [ -z "$var" ];then
	echo "there is no data from db"
	exit
else
	echo "$var"
fi
