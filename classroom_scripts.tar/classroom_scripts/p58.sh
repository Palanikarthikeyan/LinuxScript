

if [ $# -eq 0 ];then
	echo "Usage:Empty argument"
	exit
fi
if [ $# -gt 1 ];then
	echo "Usage:single argument is required"
	exit
fi

if [ "`basename $0`" == "$1" ];then
	echo "Usage: inputfile and scriptfile both are same"
	exit
fi

if [ -e $1 ]
then
	echo "file:$1 is exists"
else
	echo "file:$1 is not exists"
fi
