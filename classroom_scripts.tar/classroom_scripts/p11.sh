read -p "Enter a disk partition:" p1
read -p "Enter $p1 partition Size:" s1
read -p "Enter a disk partition:" p2
read -p "Enter $p2 partition Size:" s2

total=`expr $s1 + $s2`
echo "
-----------------------------------
Partition:$p1  Size:$s1
Partition:$p2  Size:$s2
-----------------------------------
  Total Partition Size:$total
------------------------------------"
