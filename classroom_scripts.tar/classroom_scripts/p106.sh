awk 'BEGIN{
name="root"
count=45
print name
print "name" # name 
print "Login name is:",name
print "total count value is:count"
print "total count value is:",count
}'
