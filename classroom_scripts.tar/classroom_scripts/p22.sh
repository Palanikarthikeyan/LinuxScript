read -p "Enter a filename:" fname
if [ -e $fname ];then
	echo "file:$fname is exists"
	file $fname
else
	echo "sorry file $fname is not exists"
fi
