
r1=3.525
r2=2.466
total=`echo $r1 $r2|awk '{print $1+$2}'`

status=`echo $r1 $r2|awk '{if($1 >$2){
print 0
}else{
print 1
}
}'`
if [ $status -eq 0 ];then
	echo "Ok"
else
	echo "not-ok"
fi

echo "Total:$total"
