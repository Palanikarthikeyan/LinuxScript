echo "List of files under `pwd` directory"

for var in `ls p*`
do
	echo "$var"
done
