select v in 192.168.159.128 127.0.0.1 google.com 10.20.30.40
do
	ping -c 3 $v
done
