

f1(){
	echo $1 $2 $3 ${10} ${11} ${12} ${13}
	echo $@
	echo $#
	echo "Exit from $FUNCNAME block"
}
f1 # simple functionCall

f1 httpd irb python3 apache2 10  20  30 40.45  /etc/passwd A  B  C   D
#    $1	  $2  $3      $4     $5  $6  $7 $8     $9	   10 11 12 13

f2(){
	echo $1 $2 $3
	echo $@
	echo $#
}
f2 D1 D2 D3 D4 D5
