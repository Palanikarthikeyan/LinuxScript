f1(){
	echo "outer block"
	f2 # nested functioncall
	echo "Exit from $FUNCNAME block"
}
f2(){
	echo "nested block"
	echo "Exit from $FUNCNAME block"
}
f1
echo "Exit from $0 file"
