
a=($@ data1 data2 data3)
echo "A.${#a[@]}"
echo "B.$#"
