
read -p "Enter a emp name in title case format:" ename

echo $ename|grep -qE "^[A-Z][a-z]+$"
if [ $? -eq 0 ];then
	echo "Hello...$ename"
else
	echo "Sorry invalid format"
fi
