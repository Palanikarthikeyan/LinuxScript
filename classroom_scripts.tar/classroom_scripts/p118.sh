echo "This is shell script"
echo "this is shell script"
module="sys"
python<<abc
print("this is python code")
print("This is python section")
import os
os.system("ps -f")
print("Running python pid:{}".format(os.getpid()))
import $module
print($module.path)
print("Exit from python")
abc
echo
echo "this is shell script"
echo "current process:-"
ps -f
echo "exit from script"
