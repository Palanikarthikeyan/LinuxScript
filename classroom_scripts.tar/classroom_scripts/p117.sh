echo "This is shell script"
echo "this is shell script"
python<<abc
print("this is python code")
print("This is python section")
import os
os.system("ps -f")
print("Running python pid:{}".format(os.getpid()))
print("Exit from python")
abc
echo
echo "this is shell script"
echo "current process:-"
ps -f
echo "exit from script"
