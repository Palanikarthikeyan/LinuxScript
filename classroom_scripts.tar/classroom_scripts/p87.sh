fx(){
	echo one
	echo two
	return 1
	echo three
	echo four
}
fx
echo # empty 
for v in 1 2 
do
	date;sleep 1
done
