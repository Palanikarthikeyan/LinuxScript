
for v in p1.log index.html /var/log/repo.log 1.45 80
do
	echo "Hello...$v"
done
