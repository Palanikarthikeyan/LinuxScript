
read -p "Enter a directory name:" dname
if [ -d $dname ];then
	echo "Yes input directory $dname is already exists"
	ls -ld $dname
else
	mkdir $dname
	if [ $? -eq 0 ];then
		echo "Directory creation is done"
		ls -ld $dname
	else
		echo "Directory creation is failed"
	fi
fi
