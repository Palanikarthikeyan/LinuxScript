
for v in 1 2 3
do
	for var in A B
	do
		echo "Hello"
	done
done
