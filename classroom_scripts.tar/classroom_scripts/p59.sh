hosts=()
echo "Size of an array:${#hosts[@]}"
c=0
while [ $c -lt 5 ]
do
	read -p "Enter a hostname:" name
	hosts[$c]=$name # adding new item into an existing array
c=`expr $c + 1`
done
echo "Size of an array:${#hosts[@]}"
sleep 2
echo "List of hostname details:-"
for var in ${hosts[@]}
do
	echo $var
done

hosts[3]="localhost"
echo ${hosts[3]}
echo "${hosts[@]}"
