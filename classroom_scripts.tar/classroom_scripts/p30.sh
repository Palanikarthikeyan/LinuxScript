i=0
while [ $i -lt 5 ]
do
	echo "Test server...$i"
	i=`expr $i + 1`
done

echo
i=0
while [ $i -lt 5 ]
do
	uptime
	sleep 3
	ps -f 
	echo 
	i=`expr $i + 1`
done	
