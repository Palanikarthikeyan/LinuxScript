read -p "Enter your server name:" server

case $server in
unix|UNIX|Unix) echo "matched1"
       ;;
[Ll]inux)  echo "working kernel is `uname` " ;;
[Aa][iI][xX]) echo "selected kernel is aix" ;;
 *)   echo "not-matched"
esac
