PS3="Enter your choice:"
f1(){
	echo "Kernel name:`uname -rs`"
	echo "Login shell:$SHELL"
	echo "Version:$BASH_VERSION"
	echo "Exit from $FUNCNAME block"
}

f2(){
	echo "system memory details:-"
	cat /proc/meminfo|grep -i swap
	free -m
	echo "Exit from $FUNCNAME block"
}
f3(){
	echo "Mounted File System details:-"
	df -Th $1
	echo "Exit from $FUNCNAME block"
}
f4(){
	echo "Process details:-"
	ps -f
	echo "Exit from $FUNCNAME block"
}

select var in kernel memory fs process quit
do
	case $var in
	kernel) f1 ;;
	memory) f2 ;;
	fs)	f3 / ;;
	process) f4 ;;
	quit) echo "Thank you";break ;;
	*) echo "Invalid choice"
	esac
done
