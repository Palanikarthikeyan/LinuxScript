if [ $# -ne 1 ];then
	echo "Usage: commandline args required single input file"
	echo "$0 <filename"
	exit
fi
if ! [ -f $1 ];then
	echo "Usage: Sorry file:$1 is not a reg.file"
	exit
fi
c=0	
while read var
do
	c=`expr $c + 1`
	if [ $c -gt 2 -a $c -lt 7 ];then
		echo "$c $var"
	fi
done<$1
