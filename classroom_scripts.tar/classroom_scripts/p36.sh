echo "List of conf files under /etc directory"

for var in `ls /etc/*.conf`
do
	echo $var
	sleep 1
done
