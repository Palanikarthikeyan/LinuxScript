fx(){
t=0
for v in $@ 
do
	t=`expr $v + $t`
done
}

Total=(`free -m|awk '{print $2}'|sed -e '1d' -e '3d'`)
fx ${Total[@]}
echo "Total :$t MB"
sleep 3
Used=(`free -m|awk '{print $3}'|sed '1d'`)
fx ${Used[@]}
echo "Used:$t MB"
sleep 3

Free=(`free -m|awk '{print $4}'|sed '1d'`)
fx ${Free[@]}
echo "Free space:$t MB"
