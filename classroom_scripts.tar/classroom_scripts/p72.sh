ps|while read -a var
do
	echo -e "${var[0]}|${var[-1]}"
done >r1.log
