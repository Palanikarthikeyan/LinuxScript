select v in unix linux aix sunos winx quit
do
	case $v in
	unix)  echo "selected server name is:$v"
	       echo "mounted file system details:-"
	       df -Th
	        ;;
	aix)  echo "Current process details from $v server"
	      ps -f 
	       ;;
	linux) echo "Total no.of process: `ps -e|wc -l`" ;;
        sunos|winx) echo "selected os name is:$v" ;;
	quit)   echo "Thank you" ; break ;;
	*)	echo "Try-again"
	esac
done
