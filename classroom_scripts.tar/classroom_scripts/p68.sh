
for v in 1 2 3
do
	uptime
	sleep 2
	ps -f 
	sleep 1
	date
	sleep 4
	echo # empty line
done >d2.txt
