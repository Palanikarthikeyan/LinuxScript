
while read var
do
	"$var" >>r1.log 2>&1
	if [ $? -eq 0 ];then
		echo "Status:OK"
	else
		echo "Status:Failed"
	fi
	sleep 2
done<r1.txt
