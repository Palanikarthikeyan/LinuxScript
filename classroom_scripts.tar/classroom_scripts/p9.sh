#ename="Mr.Raj paul"
#empID=1234
#edept=DBA
#epay=123456.78

echo -n "Enter a emp name:"
read ename
echo -n "Enter $ename emp id:"
read empID
echo -n "Enter $ename working dept:"
read edept
echo -n "Enter $ename basic Pay:"
read epay

echo "About $ename details
--------------------------
Emp Name:$ename
Emp ID:$empID
working dept is:$edept
Basic Pay:$epay
---------------------------"
