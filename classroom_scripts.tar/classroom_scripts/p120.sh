echo "<h1>welcome</h1>"
echo "<p>welcome to cgi program</p>"
echo "<h2><font color=green>Email:abc@hotmail.com</font></h2>"
echo

echo "<h1>welcome</h1>
<p>welcome to cgi program</p>
<h2><font color=green>Email:abc@hotmail.com</font></h2>"
echo 
cat<<abc
<html>
<head>
<title>Welcome</title>
<body>
<p>this is test paragraph</p>
<font color=green>Message</font>
</body>
</head>
</html>
abc
