
cmds=(uptime ls ps asdssd DATE "yum install httpd" whoami)

for var in "${cmds[@]}"
do
	$var >>result.log 2>&1
	if [ $? -eq 0 ];then
		echo "OK"
	else
		echo "Error"
	fi
	sleep 2
done
