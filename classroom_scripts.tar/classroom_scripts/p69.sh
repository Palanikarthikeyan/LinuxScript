<<abc
 read a data from <STDIN> --- script --- create a newfile ->write a data to FILE
	
  keyboard ....(1)........script
			  .
			  . (2)
			  .
			creating newFILE ->writing data to FILE
abc
while read var # interface to keyboard
do
	echo $var
done >r1.log # writing data to FILE
