while :
do
	uptime
	sleep 3	
	break # exit from loop
done
