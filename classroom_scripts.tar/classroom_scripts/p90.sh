
fx(){
	read -p "Enter a login name:" name
	if [ $name == "root" -o $name == "admin" ];then
		return 0
	else
		return 1
	fi
}

fx
if [ $? -eq 0 ];then
	echo "Succes"
else
	echo "Failed"
fi
