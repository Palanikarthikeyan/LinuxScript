c=0
for v in p*
do
	c=`expr $c + 1`
	echo "$c: $v"
done
echo "Total no.of files:$c"
