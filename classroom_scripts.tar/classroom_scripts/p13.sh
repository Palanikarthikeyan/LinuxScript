read -p "Enter a student name:" name
read -p "Enter a $name subject1:" s1
read -p "Enter subject2:" s2
read -p "Enter subject3:" s3

total=`expr $s1 + $s2 + $s3`
avg=`expr $total / 3`

echo "
-------------------------------
About $name details:-
-------------------------------
Name:	$name
Sub1:	$s1
Sub2:	$s2
Sub3:	$s3
--------------------------------
Total:	$total
--------------------------------
Avg:	$avg
--------------------------------"

