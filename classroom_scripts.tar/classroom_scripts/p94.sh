getdata(){
	read -p "Enter a filename:" -a fnames
	for var in ${fnames[@]}
	do
		file $var
	done
	echo "Exit from $FUNCNAME block"
}

copy(){
	while read var
	do
		echo $var
	done<$1 >$2
	echo "Exit from $FUNCNAME block"
}

if [ $# -ne 2 ];then
	echo "Usage: command line args error"
	echo "$0 <filename> <resultfile>"
	exit
fi

if [ "`basename $0`" == "$1" ];then
	echo "Usage: inputfile $1 and scriptfile both are same"
	exit
fi

if ! [ -f $1 ];then
	echo "Usage: Input file $1 is not a reg.file"
	exit
fi

if [ -e $2 ];then
	echo "Sorry file $2 is already exists"
	exit
fi
copy $1 $2 # function call with args

sleep 3

getdata

echo "Exit from $0 file"

