
if [ $# -eq 0 ];then
	echo "Usage: Commandline args is empty"
	echo "$0 <filename>"
	exit
elif [ $# -gt 1 ];then
	echo "Usage: Commandline args will take single inputfile"
	echo "$0 <filename>"
	exit
fi

if [ -f $1 ];then
	cat $1
else
	echo "file: $1 is not reg.file"
fi
