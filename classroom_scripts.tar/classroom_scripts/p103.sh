BEGIN{
print "List of sales emp details:-"
print "---------------------------"
FS=","
}
/sales/{
print
}
END{
print "Thank you"
}
