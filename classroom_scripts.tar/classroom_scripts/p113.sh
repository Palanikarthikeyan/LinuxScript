BEGIN{
s="root:x:bin:bash"
print s # string 

split(s,A,":")
print A[1]
print A[2],A[3]
}
