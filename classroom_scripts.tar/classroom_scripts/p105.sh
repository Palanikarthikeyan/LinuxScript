BEGIN{
print "List of sales emp details:-"
print "---------------------------"
FS=","
OFS="\t"
}
/sales/{
print NR,$1,$2,$NF,$NF+1000
}
END{
print "Thank you"
}
