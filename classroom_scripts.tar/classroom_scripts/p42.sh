

i=0
while [ $i -lt $size ]
do
	for var in collection
	do
		....
	done
	i=`expr $i + 1`
done

for var in collection
do
	while [ condition ]
	do
		...
	done
done
