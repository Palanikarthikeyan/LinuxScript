fx(){
	local port=50
	return $port
}
fx
echo "App port number:$?"
