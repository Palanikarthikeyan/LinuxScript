
if [ `whoami` == "root" ]
then
	read -p "Enter a packagename:" pkg
	rpm -qa |grep $pkg
	if [ $? -eq 0 ];then
		echo "Package is installed"
	else
		echo "Package is not installed"
		read -p "wish to install $pkg - yes:" choice
		if [ $choice == "yes" ];then
			yum -y install $pkg
			if [ $? -eq 0 ];then
				echo "Success - package $pkg is installed"
			else
				echo "Failed - package $pkg is failed"
			fi
		fi
	fi
else
	echo "Sorry your not root user"
fi
