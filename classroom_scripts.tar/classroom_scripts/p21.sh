read -p "Enter a enquiry number:" eno

if [ $eno -gt 500  -a $eno -lt 600 ]
then
	read -p "Enter a quotation number:" qno
	if [ $qno -gt 1000 -a $qno -lt 2000 ];then
		read -p "Enter a customer name:" cname
		if [ $cname == "cusA" -o $cname == "cusB" ]
		then
			echo -e "Enquiry:$eno\tQuotation:$qno"
			echo "Customer Name:$cname"
			echo "PO-received date:`date +%D`"
		else
			echo "Sorry customer name:$cname is not matched"	
		fi
	else
		echo "Sorry invalid quotation Number"
	fi	

else
	echo "Sorry invalid enquiry number"
fi
