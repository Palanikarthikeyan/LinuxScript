
v=`grep bash /etc/passwd` # this is scalar
echo "$v"
echo
a=(`grep bash /etc/passwd`) # this is array 
echo ${a[@]}
echo 
echo ${a[-1]}
<<abc
echo $v		Vs		echo ${a[@]}
---------			------------
10lines				each line different index
singlevariable			we can access index base 
abc
