name=`whoami`
set -x # on
if [ $name == "root" ];then
	echo "Matched1"
elif [ $name == "userA" ];then
	echo "Matched2"
elif [ $name == "userB" ];then
	echo "Matched3"
elif [ $name == "apelix" ];then
	echo "Matched4"
elif [ $name == "student" ];then
	echo "Matched5"
else
	echo "Not-Matched"
fi
set +x # off
echo "Test code"
echo "End of the line"
