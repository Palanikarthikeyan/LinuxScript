
while read var
do
  echo $var
done<r1.log >r2.log

