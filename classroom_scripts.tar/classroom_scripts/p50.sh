for((i=0;i<3;i++))
do
	echo "Test code...$i"
done
echo
for((;;))
do
	uptime
	break # exit from loop
done
